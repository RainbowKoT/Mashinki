﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using Word = Microsoft.Office.Interop.Word;
using Excel = Microsoft.Office.Interop.Excel;

namespace boarding.Views
{
    public partial class ReportPage : Page
    {
        private string connectionString = "Server=localhost\\SQLEXPRESS;Database=boarding_app;Trusted_Connection=True;";

        public ReportPage()
        {
            InitializeComponent();
            dpStartDate.SelectedDate = DateTime.Today.AddMonths(-1);
            dpEndDate.SelectedDate = DateTime.Today;

            this.Loaded += ReportPage_Loaded;
        }

        private void ReportPage_Loaded(object sender, RoutedEventArgs e)
        {
            cbAllData.Checked += cbAllData_Checked;
            cbAllData.Unchecked += cbAllData_Checked; 
        }

        private void cbAllData_Checked(object sender, RoutedEventArgs e)
        {
            bool isChecked = cbAllData?.IsChecked ?? false;

            if (cbPets != null) cbPets.IsChecked = isChecked;
            if (cbCheckups != null) cbCheckups.IsChecked = isChecked;
            if (cbPets != null) cbPets.IsEnabled = !isChecked;
            if (cbCheckups != null) cbCheckups.IsEnabled = !isChecked;
        }


        private void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!dpStartDate.SelectedDate.HasValue || !dpEndDate.SelectedDate.HasValue)
                {
                    MessageBox.Show("Укажите период отчета", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (dpStartDate.SelectedDate > dpEndDate.SelectedDate)
                {
                    MessageBox.Show("Дата начала не может быть позже даты окончания", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var selectedTables = new List<string>();
                if (cbPets.IsChecked ?? false) selectedTables.Add("Pets");
                if (cbCheckups.IsChecked ?? false) selectedTables.Add("Checkups");

                if (selectedTables.Count == 0)
                {
                    MessageBox.Show("Выберите хотя бы один тип данных для отчета", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                string format = rbWord.IsChecked ?? false ? "Word" :
                              rbExcel.IsChecked ?? false ? "Excel" : "PDF";
                bool isTableFormat = rbTable.IsChecked ?? false;

                var saveFileDialog = new Microsoft.Win32.SaveFileDialog();
                saveFileDialog.Filter = format == "Word" ? "Word Documents|*.docx" :
                                       format == "Excel" ? "Excel Files|*.xlsx" : "PDF Files|*.pdf";
                saveFileDialog.FileName = $"Отчет_по_животным_{DateTime.Now:yyyyMMdd}";

                if (saveFileDialog.ShowDialog() == true)
                {
                    if (format == "Excel")
                    {
                        ExportToExcel(saveFileDialog.FileName, selectedTables,
                                     dpStartDate.SelectedDate, dpEndDate.SelectedDate);
                    }
                    else
                    {
                        ExportToWord(saveFileDialog.FileName, selectedTables,
                                    dpStartDate.SelectedDate, dpEndDate.SelectedDate,
                                    isTableFormat, format == "PDF");
                    }

                    MessageBox.Show("Отчет успешно сформирован", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при формировании отчета: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ExportToWord(string filePath, List<string> selectedTables,
                                DateTime? startDate, DateTime? endDate,
                                bool isTableFormat, bool saveAsPdf)
        {
            Word.Application wordApp = null;
            Word.Document doc = null;

            try
            {
                wordApp = new Word.Application();
                wordApp.Visible = false;
                wordApp.DisplayAlerts = Word.WdAlertLevel.wdAlertsNone;

                doc = wordApp.Documents.Add();

                var title = doc.Paragraphs.Add();
                title.Range.Text = "Отчет по животным и осмотрам";
                title.Range.Font.Bold = 1;
                title.Range.Font.Size = 16;
                title.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                title.Range.InsertParagraphAfter();

                var period = doc.Paragraphs.Add();
                period.Range.Text = $"Период: {startDate:dd.MM.yyyy} - {endDate:dd.MM.yyyy}";
                period.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                period.Range.InsertParagraphAfter();

                var date = doc.Paragraphs.Add();
                date.Range.Text = $"Сформирован: {DateTime.Now:dd.MM.yyyy HH:mm}";
                date.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                date.Range.InsertParagraphAfter();

                doc.Paragraphs.Add().Range.InsertParagraphAfter();

                System.Data.DataTable petsTable = null;
                System.Data.DataTable checkupsTable = null;

                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    if (selectedTables.Contains("Pets"))
                    {
                        var petsAdapter = new SqlDataAdapter(
                            "SELECT pet_id, type, name, breed, gender, weight, age, health FROM Pet",
                            connection);
                        petsTable = new System.Data.DataTable();
                        petsAdapter.Fill(petsTable);
                    }

                    if (selectedTables.Contains("Checkups"))
                    {
                        string checkupQuery = @"SELECT c.checkup_id, c.date, c.results, 
                                              p.pet_id, p.name as pet_name
                                              FROM Checkup c 
                                              JOIN Pet p ON c.pet_id = p.pet_id";

                        if (startDate.HasValue && endDate.HasValue)
                        {
                            checkupQuery += $" WHERE c.date BETWEEN '{startDate:yyyy-MM-dd}' AND '{endDate:yyyy-MM-dd}'";
                        }

                        var checkupsAdapter = new SqlDataAdapter(checkupQuery, connection);
                        checkupsTable = new System.Data.DataTable();
                        checkupsAdapter.Fill(checkupsTable);
                    }
                }

                foreach (var table in selectedTables)
                {
                    var section = doc.Paragraphs.Add();
                    section.Range.Text = table == "Pets" ? "Данные о животных" : "Данные об осмотрах";
                    section.Range.Font.Bold = 1;
                    section.Range.Font.Size = 14;
                    section.Range.InsertParagraphAfter();

                    if (isTableFormat)
                    {
                        if (table == "Pets" && petsTable != null)
                        {
                            ExportDataTableToWord(doc, petsTable);
                        }
                        else if (table == "Checkups" && checkupsTable != null)
                        {
                            ExportDataTableToWord(doc, checkupsTable);
                        }
                    }
                    else
                    {
                        if (table == "Pets" && petsTable != null)
                        {
                            ExportDataToWordText(doc, petsTable);
                        }
                        else if (table == "Checkups" && checkupsTable != null)
                        {
                            ExportDataToWordText(doc, checkupsTable);
                        }
                    }

                    doc.Paragraphs.Add().Range.InsertParagraphAfter();
                }

                Word.WdSaveFormat format = saveAsPdf ? Word.WdSaveFormat.wdFormatPDF : Word.WdSaveFormat.wdFormatDocumentDefault;
                doc.SaveAs2(filePath, format);

                object doNotSave = Word.WdSaveOptions.wdDoNotSaveChanges;
                doc.Close(ref doNotSave);
                wordApp.Quit();

                System.Diagnostics.Process.Start(filePath);
            }
            catch (Exception)
            {
                if (doc != null)
                {
                    object doNotSave = Word.WdSaveOptions.wdDoNotSaveChanges;
                    doc.Close(ref doNotSave);
                }
                if (wordApp != null) wordApp.Quit();
                throw;
            }
        }

        private void ExportDataTableToWord(Word.Document doc, System.Data.DataTable dataTable)
        {
            Word.Table table = doc.Tables.Add(doc.Range(doc.Content.End - 1),
                                             dataTable.Rows.Count + 1,
                                             dataTable.Columns.Count);

            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                table.Cell(1, i + 1).Range.Text = dataTable.Columns[i].ColumnName;
            }

            for (int row = 0; row < dataTable.Rows.Count; row++)
            {
                for (int col = 0; col < dataTable.Columns.Count; col++)
                {
                    table.Cell(row + 2, col + 1).Range.Text = dataTable.Rows[row][col].ToString();
                }
            }

            table.Range.Font.Size = 10;
            table.Rows[1].Range.Font.Bold = 1;
            table.Rows[1].Range.Shading.BackgroundPatternColor = Word.WdColor.wdColorGray15;
            table.Borders.Enable = 1;
            table.AllowAutoFit = true;
            table.AutoFitBehavior(Word.WdAutoFitBehavior.wdAutoFitContent);
        }

        private void ExportDataToWordText(Word.Document doc, System.Data.DataTable dataTable)
        {
            foreach (System.Data.DataRow row in dataTable.Rows)
            {
                var paragraph = doc.Paragraphs.Add();
                foreach (System.Data.DataColumn col in dataTable.Columns)
                {
                    paragraph.Range.Text += $"{col.ColumnName}: {row[col]}\t";
                }
                paragraph.Range.InsertParagraphAfter();
            }
        }

        private void ExportToExcel(string filePath, List<string> selectedTables,
                                 DateTime? startDate, DateTime? endDate)
        {
            Excel.Application excelApp = null;
            Excel.Workbook workbook = null;

            try
            {
                excelApp = new Excel.Application();
                excelApp.Visible = false;
                workbook = excelApp.Workbooks.Add();

                System.Data.DataTable petsTable = null;
                System.Data.DataTable checkupsTable = null;

                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    if (selectedTables.Contains("Pets"))
                    {
                        var petsAdapter = new SqlDataAdapter(
                            "SELECT pet_id, type, name, breed, gender, weight, age, health FROM Pet",
                            connection);
                        petsTable = new System.Data.DataTable();
                        petsAdapter.Fill(petsTable);
                    }

                    if (selectedTables.Contains("Checkups"))
                    {
                        string checkupQuery = @"SELECT c.checkup_id, c.date, c.results, 
                                              p.pet_id, p.name as pet_name
                                              FROM Checkup c 
                                              JOIN Pet p ON c.pet_id = p.pet_id";
                        if (startDate.HasValue && endDate.HasValue)
                        {
                            checkupQuery += $" WHERE c.date BETWEEN '{startDate:yyyy-MM-dd}' AND '{endDate:yyyy-MM-dd}'";
                        }

                        var checkupsAdapter = new SqlDataAdapter(checkupQuery, connection);
                        checkupsTable = new System.Data.DataTable();
                        checkupsAdapter.Fill(checkupsTable);
                    }
                }

                foreach (var table in selectedTables)
                {
                    Excel.Worksheet worksheet;
                    if (workbook.Sheets.Count < selectedTables.IndexOf(table) + 1)
                    {
                        worksheet = (Excel.Worksheet)workbook.Sheets.Add();
                    }
                    else
                    {
                        worksheet = (Excel.Worksheet)workbook.Sheets[selectedTables.IndexOf(table) + 1];
                    }

                    worksheet.Name = table == "Pets" ? "Животные" : "Осмотры";

                    System.Data.DataTable dataToExport = table == "Pets" ? petsTable : checkupsTable;
                    if (dataToExport != null)
                    {
                        ExportDataTableToExcel(worksheet, dataToExport);
                    }
                }

                while (workbook.Sheets.Count > selectedTables.Count)
                {
                    ((Excel.Worksheet)workbook.Sheets[workbook.Sheets.Count]).Delete();
                }

                workbook.SaveAs(filePath);
                System.Diagnostics.Process.Start(filePath);
            }
            catch (Exception)
            {
                if (workbook != null) workbook.Close(false);
                if (excelApp != null) excelApp.Quit();
                throw;
            }
            finally
            {
                if (workbook != null) workbook.Close(false);
                if (excelApp != null) excelApp.Quit();
            }
        }

        private void ExportDataTableToExcel(Excel.Worksheet worksheet, System.Data.DataTable dataTable)
        {
            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                worksheet.Cells[1, i + 1] = dataTable.Columns[i].ColumnName;
            }

            for (int row = 0; row < dataTable.Rows.Count; row++)
            {
                for (int col = 0; col < dataTable.Columns.Count; col++)
                {
                    worksheet.Cells[row + 2, col + 1] = dataTable.Rows[row][col].ToString();
                }
            }

            Excel.Range headerRange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[1, dataTable.Columns.Count]];
            headerRange.Font.Bold = true;


            worksheet.Columns.AutoFit();
        }
    }
}
