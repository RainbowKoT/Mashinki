﻿using System;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
namespace boarding.Views
{
    public partial class dashboardpage : Page
    {
        private string connectionString = "Server=localhost\\SQLEXPRESS;Database=boarding_app;Trusted_Connection=True;";
        public dashboardpage()
        {
            InitializeComponent();
            LoadStatistics();
        }
        private void LoadStatistics()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand petCmd = new SqlCommand("SELECT COUNT(*) FROM Pet", connection);
                    int petCount = (int)petCmd.ExecuteScalar();
                    AnimalsCountText.Text = petCount.ToString();
                    SqlCommand checkupCmd = new SqlCommand(
                        "SELECT COUNT(*) FROM Checkup WHERE date >= @startDate", connection);
                    checkupCmd.Parameters.AddWithValue("@startDate", DateTime.Today.AddMonths(-1));
                    int checkupCount = (int)checkupCmd.ExecuteScalar();
                    InspectionsCountText.Text = checkupCount.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке статистики: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void VetPanelButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var vetWindow = new vetpage();
                vetWindow.Show();
                Window.GetWindow(this)?.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии ветеринарной панели: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}