﻿using System.Windows;

namespace boarding.Views
{
    public partial class AddEditPetWindow : Window
    {
        public string PetType => txtType.Text;
        public string PetName => txtName.Text;
        public string Breed => txtBreed.Text;
        public string Gender => txtGender.Text;
        public double Weight => double.Parse(txtWeight.Text);
        public int Age => int.Parse(txtAge.Text);
        public string Health => txtHealth.Text;
        public int PetId { get; private set; }
        public AddEditPetWindow()
        {
            InitializeComponent();
            Title = "Добавить животное";
        }
        public AddEditPetWindow(int petId) : this()
        {
            PetId = petId;
        }
        public AddEditPetWindow(string type, string name, string breed, string gender,
                              double weight, int age, string health, int petId)
            : this()
        {
            txtType.Text = type;
            txtName.Text = name;
            txtBreed.Text = breed;
            txtGender.Text = gender;
            txtWeight.Text = weight.ToString();
            txtAge.Text = age.ToString();
            txtHealth.Text = health;
            PetId = petId;
            Title = "Изменить животное";
        }
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateInput())
            {
                DialogResult = true;
                Close();
            }
        }
        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(PetType) ||
                string.IsNullOrWhiteSpace(PetName) ||
                string.IsNullOrWhiteSpace(Breed) ||
                string.IsNullOrWhiteSpace(Gender))
            {
                MessageBox.Show("Заполните все обязательные поля");
                return false;
            }
            if (!double.TryParse(txtWeight.Text, out _) ||
                !int.TryParse(txtAge.Text, out _))
            {
                MessageBox.Show("Вес и возраст должны быть числами");
                return false;
            }
            return true;
        }
    }
}
