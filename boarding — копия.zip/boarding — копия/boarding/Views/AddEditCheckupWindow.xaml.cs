﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace boarding.Views
{
    public partial class AddEditCheckupWindow : Window
    {
        private string connectionString = "Server=localhost\\SQLEXPRESS;Database=boarding_app;Trusted_Connection=True;";

        public DateTime CheckupDate => dpDate.SelectedDate ?? DateTime.Now;
        public string Results => txtResults.Text;
        public int PetId => (cbPets.SelectedItem as DataRowView)?["pet_id"] as int? ?? 0;
        public int CheckupId { get; private set; }
        public AddEditCheckupWindow()
        {
            InitializeComponent();
            dpDate.SelectedDate = DateTime.Today;
            Title = "Добавить осмотр";
            LoadPets();
        }
        public AddEditCheckupWindow(int checkupId) : this()
        {
            CheckupId = checkupId;
        }
        public AddEditCheckupWindow(DateTime date, string results, int petId, int checkupId)
            : this()
        {
            dpDate.SelectedDate = date;
            txtResults.Text = results;
            foreach (DataRowView item in cbPets.Items)
            {
                if ((int)item["pet_id"] == petId)
                {
                    cbPets.SelectedItem = item;
                    break;
                }
            }
            CheckupId = checkupId;
            Title = "Изменить осмотр";
        }
        private void LoadPets()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT pet_id FROM Pet ORDER BY pet_id";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    cbPets.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки списка животных: {ex.Message}");
            }
        }
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateInput())
            {
                DialogResult = true;
                Close();
            }
        }
        private bool ValidateInput()
        {
            if (dpDate.SelectedDate == null ||
                string.IsNullOrWhiteSpace(Results))
            {
                MessageBox.Show("Заполните все обязательные поля");
                return false;
            }

            if (cbPets.SelectedItem == null)
            {
                MessageBox.Show("Выберите животное");
                return false;
            }
            return true;
        }
    }
}