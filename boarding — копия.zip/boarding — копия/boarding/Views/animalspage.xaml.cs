﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace boarding.Views
{
    public partial class animalspage : Page
    {
        private string connectionString = "Server=localhost\\SQLEXPRESS;Database=boarding_app;Trusted_Connection=True;";

        public animalspage()
        {
            InitializeComponent();
            LoadPetsData();
        }
        private void LoadPetsData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM Pet";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    petsDataGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
            }
        }
        private int GetNextPetId()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT ISNULL(MAX(pet_id), 0) + 1 FROM Pet";
                    SqlCommand command = new SqlCommand(query, connection);
                    int nextId = (int)command.ExecuteScalar();
                    return nextId;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении нового ID: {ex.Message}");
                return 1; // Если ошибка, вернём 1 по умолчанию
            }
        }
        private void AddPet_Click(object sender, RoutedEventArgs e)
        {
            int newPetId = GetNextPetId();
            var addWindow = new AddEditPetWindow(newPetId);
            if (addWindow.ShowDialog() == true)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = @"INSERT INTO Pet (pet_id, type, name, breed, gender, weight, age, health) 
                                         VALUES (@pet_id, @type, @name, @breed, @gender, @weight, @age, @health)";

                        SqlCommand cmd = new SqlCommand(query, connection);
                        cmd.Parameters.AddWithValue("@pet_id", addWindow.PetId);
                        cmd.Parameters.AddWithValue("@type", addWindow.PetType);
                        cmd.Parameters.AddWithValue("@name", addWindow.PetName);
                        cmd.Parameters.AddWithValue("@breed", addWindow.Breed);
                        cmd.Parameters.AddWithValue("@gender", addWindow.Gender);
                        cmd.Parameters.AddWithValue("@weight", addWindow.Weight);
                        cmd.Parameters.AddWithValue("@age", addWindow.Age);
                        cmd.Parameters.AddWithValue("@health", addWindow.Health);

                        cmd.ExecuteNonQuery();
                    }
                    LoadPetsData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка добавления: {ex.Message}");
                }
            }
        }
        private void EditPet_Click(object sender, RoutedEventArgs e)
        {
            if (petsDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите животное для редактирования");
                return;
            }
            DataRowView row = (DataRowView)petsDataGrid.SelectedItem;
            var editWindow = new AddEditPetWindow(
                row["type"].ToString(),
                row["name"].ToString(),
                row["breed"].ToString(),
                row["gender"].ToString(),
                Convert.ToDouble(row["weight"]),
                Convert.ToInt32(row["age"]),
                row["health"].ToString(),
                Convert.ToInt32(row["pet_id"]));
            if (editWindow.ShowDialog() == true)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = @"UPDATE Pet SET 
                                      type = @type, 
                                      name = @name, 
                                      breed = @breed, 
                                      gender = @gender, 
                                      weight = @weight, 
                                      age = @age, 
                                      health = @health
                                      WHERE pet_id = @pet_id";

                        SqlCommand cmd = new SqlCommand(query, connection);
                        cmd.Parameters.AddWithValue("@type", editWindow.PetType);
                        cmd.Parameters.AddWithValue("@name", editWindow.PetName);
                        cmd.Parameters.AddWithValue("@breed", editWindow.Breed);
                        cmd.Parameters.AddWithValue("@gender", editWindow.Gender);
                        cmd.Parameters.AddWithValue("@weight", editWindow.Weight);
                        cmd.Parameters.AddWithValue("@age", editWindow.Age);
                        cmd.Parameters.AddWithValue("@health", editWindow.Health);
                        cmd.Parameters.AddWithValue("@pet_id", editWindow.PetId);

                        cmd.ExecuteNonQuery();
                    }
                    LoadPetsData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка редактирования: {ex.Message}");
                }
            }
        }
        private void RefreshData_Click(object sender, RoutedEventArgs e)
        {
            LoadPetsData();
        }
    }
}
