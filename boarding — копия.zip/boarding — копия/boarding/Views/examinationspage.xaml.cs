﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace boarding.Views
{
    public partial class examinationspage : Page
    {
        private string connectionString = "Server=localhost\\SQLEXPRESS;Database=boarding_app;Trusted_Connection=True;";
        public examinationspage()
        {
            InitializeComponent();
            LoadCheckupsData();
        }
        private void LoadCheckupsData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM Checkup";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    checkupsDataGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
            }
        }
        private int GetNextCheckupId()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT ISNULL(MAX(checkup_id), 0) + 1 FROM Checkup";
                    SqlCommand command = new SqlCommand(query, connection);
                    return (int)command.ExecuteScalar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении нового ID: {ex.Message}");
                return 1;
            }
        }
        private void AddCheckup_Click(object sender, RoutedEventArgs e)
        {
            int newCheckupId = GetNextCheckupId();
            var addWindow = new AddEditCheckupWindow(newCheckupId);
            if (addWindow.ShowDialog() == true)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = @"INSERT INTO Checkup (checkup_id, date, results, pet_id) 
                                      VALUES (@checkup_id, @date, @results, @pet_id)";

                        SqlCommand cmd = new SqlCommand(query, connection);
                        cmd.Parameters.AddWithValue("@checkup_id", addWindow.CheckupId);
                        cmd.Parameters.AddWithValue("@date", addWindow.CheckupDate);
                        cmd.Parameters.AddWithValue("@results", addWindow.Results);
                        cmd.Parameters.AddWithValue("@pet_id", addWindow.PetId);

                        cmd.ExecuteNonQuery();
                    }
                    LoadCheckupsData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка добавления: {ex.Message}");
                }
            }
        }
        private void EditCheckup_Click(object sender, RoutedEventArgs e)
        {
            if (checkupsDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите осмотр для редактирования");
                return;
            }
            DataRowView row = (DataRowView)checkupsDataGrid.SelectedItem;
            var editWindow = new AddEditCheckupWindow(
                Convert.ToDateTime(row["date"]),
                row["results"].ToString(),
                Convert.ToInt32(row["pet_id"]),
                Convert.ToInt32(row["checkup_id"]));
            if (editWindow.ShowDialog() == true)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = @"UPDATE Checkup SET 
                                      date = @date, 
                                      results = @results, 
                                      pet_id = @pet_id
                                      WHERE checkup_id = @checkup_id";
                        SqlCommand cmd = new SqlCommand(query, connection);
                        cmd.Parameters.AddWithValue("@date", editWindow.CheckupDate);
                        cmd.Parameters.AddWithValue("@results", editWindow.Results);
                        cmd.Parameters.AddWithValue("@pet_id", editWindow.PetId);
                        cmd.Parameters.AddWithValue("@checkup_id", editWindow.CheckupId);
                        cmd.ExecuteNonQuery();
                    }
                    LoadCheckupsData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка редактирования: {ex.Message}");
                }
            }
        }
        private void RefreshData_Click(object sender, RoutedEventArgs e)
        {
            LoadCheckupsData();
        }
    }
}