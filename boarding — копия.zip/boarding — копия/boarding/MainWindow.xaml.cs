﻿using System;
using System.Windows;
using System.Windows.Controls;
using boarding.Views;

namespace boarding
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainContentFrame.Navigate(new Uri("/Views/dashboardpage.xaml", UriKind.Relative));
        }

        private void NavigationButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            string pageTag = button.Tag.ToString();

            switch (pageTag.ToLower()) // Используем ToLower для унификации сравнения
            {
                case "dashboardpage":
                    MainContentFrame.Navigate(new Uri("/Views/dashboardpage.xaml", UriKind.Relative));
                    break;
                case "vetpage":
                    // Создаем и показываем окно ветеринара
                    var vetWindow = new vetpage();
                    vetWindow.Show();
                    // Закрываем текущее окно
                    this.Close();
                    break;
            }
        }

        private void BtnProfile_Click(object sender, RoutedEventArgs e)
        {
            MainContentFrame.Navigate(new Uri("/Views/profilepage.xaml", UriKind.Relative));
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            var loginWindow = new authoriz();
            loginWindow.Show();
            this.Close();
        }
    }
}