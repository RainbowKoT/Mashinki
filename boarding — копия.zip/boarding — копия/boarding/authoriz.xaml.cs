﻿using System;
using System.Text;
using System.Windows;

namespace boarding
{
    public partial class authoriz : Window
    {
        public authoriz()
        {
            InitializeComponent();
            GenerateNewCaptcha();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            //проверка заполнения всех полей
            if (!CheckRequiredFields())
            {
                ShowErrorMessage("Все поля обязательны для заполнения!");
                return;
            }

            if (txtCaptcha.Text != lblCaptcha.Text)
            {
                ShowErrorMessage("Неверная капча! Попробуйте еще раз.");
                GenerateNewCaptcha();
                return;
            }

            if (IsValidCredentials(txtUsername.Text, txtPassword.Password))
            {
                MessageBoxResult result = MessageBox.Show(
                    "Здравствуйте, Мария!",
                    "Успешная авторизация",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                if (result == MessageBoxResult.OK)
                {
                    OpenMainWindow();
                    this.Close();
                }
            }
            else
            {
                ShowErrorMessage("Неверный логин или пароль!");
                GenerateNewCaptcha();
            }
        }

        //проверка заполнения обязательных полей
        private bool CheckRequiredFields()
        {
            return !string.IsNullOrWhiteSpace(txtUsername.Text) &&
                   !string.IsNullOrWhiteSpace(txtPassword.Password) &&
                   !string.IsNullOrWhiteSpace(txtCaptcha.Text);
        }

        private bool IsValidCredentials(string login, string password)
        {
            return login == "маря1989" && password == "маря1989";
        }

        private void ShowErrorMessage(string message)
        {
            MessageBox.Show(
                message,
                "Ошибка авторизации",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }

        private void OpenMainWindow()
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }

        private void BtnRefreshCaptcha_Click(object sender, RoutedEventArgs e)
        {
            GenerateNewCaptcha();
        }

        private void GenerateNewCaptcha()
        {
            const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
            var random = new Random();
            var captcha = new StringBuilder(6);

            for (int i = 0; i < 6; i++)
            {
                captcha.Append(chars[random.Next(chars.Length)]);
            }

            lblCaptcha.Text = captcha.ToString();
            txtCaptcha.Clear();
            txtCaptcha.Focus();
        }

        private void Border_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (e.ChangedButton == System.Windows.Input.MouseButton.Left)
                this.DragMove();
        }
    }
}