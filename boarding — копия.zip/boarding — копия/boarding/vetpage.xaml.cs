﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace boarding.Views
{
    public partial class vetpage : Window
    {
        public vetpage()
        {
            try
            {
                InitializeComponent();
                // Загружаем стартовую страницу
                contentFrame.Navigate(new animalspage());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка инициализации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                Close();
            }
        }

        private void Animals_Click(object sender, RoutedEventArgs e)
        {
            SafeNavigate(() => new animalspage());
        }

        private void Examinations_Click(object sender, RoutedEventArgs e)
        {
            SafeNavigate(() => new examinationspage());
        }

        private void Report_Click(object sender, RoutedEventArgs e)
        {
            SafeNavigate(() => new ReportPage());
        }

        private void SafeNavigate(Func<Page> pageFactory)
        {
            try
            {
                var page = pageFactory();
                contentFrame.Navigate(page);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка навигации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void GoToMain_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Создаем новое главное окно
                var mainWindow = new MainWindow();
                Application.Current.MainWindow = mainWindow;
                mainWindow.Show();

                // Закрываем текущее окно
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка перехода: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}